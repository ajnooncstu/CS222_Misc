#!/bin/bash

# Define the base directory for the scavenger hunt
BASE_DIR="."

# Initialize a flag to check if all tasks are done correctly
all_tasks_done=true

# Function to check file existence and correct content
check_file_content() {
    local file_path="$1"
    local expected_content="$2"
    
    if [[ -f "$file_path" ]]; then
        actual_content=$(cat "$file_path")
        if [[ "$actual_content" == *"$expected_content"* ]]; then
            echo "✅ $file_path contains the correct content: $expected_content"
        else
            echo "❌ $file_path does not contain the expected content: $expected_content"
            all_tasks_done=false
        fi
    else
        echo "❌ $file_path does not exist."
        all_tasks_done=false
    fi
}

# Function to check if a file exists in a specific directory
check_file_exists() {
    local file_path="$1"
    
    if [[ -f "$file_path" ]]; then
        echo "✅ $file_path exists."
    else
        echo "❌ $file_path does not exist."
        all_tasks_done=false
    fi
}

# Function to check if a file is hidden
check_hidden_file_exists() {
    local dir_path="$1"
    local hidden_file="$2"
    
    if [[ -f "$dir_path/$hidden_file" ]]; then
        echo "✅ Hidden file $hidden_file exists in $dir_path."
    else
        echo "❌ Hidden file $hidden_file does not exist in $dir_path."
        all_tasks_done=false
    fi
}

# Check if all tasks are done correctly
echo "Checking scavenger hunt tasks..."

# Check for initial files
check_file_exists "$BASE_DIR/welcome.txt"
check_file_exists "$BASE_DIR/instructions.txt"

# Check the 'documents' directory for clues and hidden files
check_file_exists "$BASE_DIR/documents/clue1.txt"
check_file_content "$BASE_DIR/documents/clue1.txt" "L"
check_file_exists "$BASE_DIR/documents/secret_note.txt"
check_file_content "$BASE_DIR/documents/secret_note.txt" "i"
check_hidden_file_exists "$BASE_DIR/documents" ".hidden_clue.txt"
check_file_content "$BASE_DIR/documents/.hidden_clue.txt" "n"
check_file_exists "$BASE_DIR/documents/next_step.txt"
check_file_content "$BASE_DIR/documents/next_step.txt" "u"

# Check the 'pictures' directory
check_file_exists "$BASE_DIR/pictures/clue2.txt"
check_file_content "$BASE_DIR/pictures/clue2.txt" "x"

# Check the 'secrets' directory
check_file_exists "$BASE_DIR/secrets/clue3.txt"
check_file_content "$BASE_DIR/secrets/clue3.txt" "R"
check_file_exists "$BASE_DIR/secrets/search_here.txt"
check_file_content "$BASE_DIR/secrets/grep_clue.txt" "o"
check_file_exists "$BASE_DIR/secrets/message.txt"

# Check if 'message.txt' has been moved to the 'completed' directory
check_file_exists "$BASE_DIR/completed/message.txt"

# Check the 'archive' directory
check_file_exists "$BASE_DIR/archive/final_clue.txt"
check_file_content "$BASE_DIR/archive/final_clue.txt" "o"
check_file_exists "$BASE_DIR/archive/congratulations.txt"
check_file_content "$BASE_DIR/archive/congratulations.txt" "c"
check_file_content "$BASE_DIR/archive/congratulations.txt" "k"

# Check if 'found_it.txt' was created in the 'archive' directory and contains a team name
check_file_content "$BASE_DIR/archive/found_it.txt" "Your Team Name"

# Summary of the results
if $all_tasks_done; then
    echo "🎉 All tasks are correctly done! The scavenger hunt is complete!"
else
    echo "🔍 Some tasks were not done correctly. Please review the instructions."
fi
